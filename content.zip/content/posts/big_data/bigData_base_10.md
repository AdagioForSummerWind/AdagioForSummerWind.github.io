---
title: "BigData_base_10"
date: 2021-12-06T16:20:14+08:00
lastmod: 2021-12-06
tags: [big_data]
categories: [School courses]
slug: support vector machine
draft: true
---
# 支持向量机
## 支持向量机的基本思想
## 线性支持向量机


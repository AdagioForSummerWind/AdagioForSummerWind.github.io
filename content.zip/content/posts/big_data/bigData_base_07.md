---
title: "BigData_base_07"
date: 2021-12-06T15:55:56+08:00
lastmod: 2021-12-06
tags: [big_data]
categories: [School courses]
slug: basis of regression prediction
draft: true
---
# 回归预测基础
## 回归预测的基本概念
回归（regression）：预测给定数据对象的目标值（与分类的类别对应）

回归任务可以用一个形式化函数表示： 
- 𝑦 = 𝑓(𝒙) ,
- 其中 𝒙 ∈ 𝔻, 𝑦 ∈ ℝ
- 回归函数𝑓(𝒙) 经过运算可以输出一个连续的实数值 𝑦 ，即“回归模型”
## 线性回归
## 基于梯度下降法的线性回归
## 基于最小二乘法的线性回归（optional）


---
title: "BidData_catalogue"
date: 2021-11-08T16:39:35+08:00
lastmod:
tags: [catalogue]
categories: [Catalogue]
slug: BigData_catalogue
draft: true
---
HITSZ2021大数据导论课程笔记
* 绪论
* 大数据存储与处理框架（Hadoop）
* 数据理解及数据预处理方法
* 大数据的分类与预测算法
* 大数据的聚类与离群点检测算法
* 大数据的关联规则挖掘及其应用



---
title: "DIP_catalogue"
date: 2022-02-25T09:19:46+08:00
lastmod:
tags: []
categories: []
slug:
draft: true
---
- Introduction & Fundamentals
    - What is digital image processing?
    - Human vision system
    - Image acquisition
    - Sampling and Quantization
    - Resolution
    - Basic Relationships Between Pixels
    - Key stages in digital image processing
- Image Enhancement（时间多一点） 
- Morphological Image Processing
- Image Segmentation 
- Image Restoration
- Color image processing
- Representation & Description
- Object Recognition
- Image Compression


---
title: "CA_base_03"
date: 2021-12-13T14:00:43+08:00
lastmod:
tags: []
categories: []
slug:
draft: true
---
# 计算机硬件结构
## 5 计算机组成原理和结构
## 6 计算机总线接口技术
## 7 计算机启动过程分析


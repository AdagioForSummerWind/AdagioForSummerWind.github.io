---
title: "NIPS18_BRITS"
date: 2022-05-21T14:42:03+08:00
lastmod:
tags: [papers]
categories: [Graduation project]
slug: TRMF for High-dimensional Time Series Prediction
draft: true
---
> BRITS: Bidirectional Recurrent Imputation for Time Series

# BRITS: Bidirectional Recurrent Imputation for Time Series


---
title: "CN_base_05"
date: 2022-01-23T10:50:41+08:00
lastmod:
tags: []
categories: []
slug:
draft: true
---
# 网络层
## 4.1 网络层服务
## 4.2 虚电路网络与数据报网络
## 4.3 路由器体系结构
## 4.4 IP协议
## 4.5 IP相关协议
## 4.6 路由算法
## 4.7路由协议

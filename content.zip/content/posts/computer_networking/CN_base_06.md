---
title: "CN_base_06"
date: 2022-01-23T10:50:53+08:00
lastmod:
tags: []
categories: []
slug:
draft: true
---
# 传输层
开始端到端传输通讯。
## 5.1 传输层服务
## 5.2 传输层多路复用/分用
## 5.3 UDP协议
## 5.4 TCP协议
### 5.4.1 TCP段结构
### 5.4.2 TCP可靠数据传输
### 5.4.3 TCP流量控制
### 5.4.4 TCP连接控制
### 5.4.5 TCP拥塞控制
### 5.4.6 TCP性能

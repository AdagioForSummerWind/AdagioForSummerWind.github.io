---
title: "Exam_Summary_SEK"
date: 2022-01-20T10:53:17+08:00
lastmod:
tags: []
categories: []
slug:
draft: true
---

## 习题
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230100042.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230100208.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230100400.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230101005.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230101321.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230101410.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230101757.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230102424.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230102604.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230102944.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230103106.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230105234.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230105340.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230110006.png)
软件危机：硬件技术的进步，软件技术的进步不能满足发展的需要。软件危机表现在四个方面：钱与时间，要求，维护性，可靠性。造成软件危机的原因：规模和结构，管理，经费，技术，工具
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230110842.png)
![](https://raw.githubusercontent.com/JF-011101/Image_hosting_rep/main/20211230111010.png)
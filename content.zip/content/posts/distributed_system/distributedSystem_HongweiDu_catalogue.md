---
title: "DistributedSystem_HongweiDu_catalogue"
date: 2022-01-01T15:21:52+08:00
lastmod: 2022-01-02
tags: [catalogue, distributed system]
categories: [Catalogue, School courses]
slug: DS_Catalogue
draft: true
---
- [DHW_01](https://JF-011101.github.io/2021/distributedsystem-hongweidu-intro/)(intro)
    - topics
    - motivation
    - definition
    - features
    - challanges
    - conclusino
- [DHW_02](https://JF-011101.github.io/2021/distributedsystem-hongweidu-system-modules/)(system modules)
    - physical model
    - architectural model
    - fundamental model
- [DHW_03](https://JF-011101.github.io/2021/physical-time/)(physical time)
- [DHW_04](https://JF-011101.github.io/2021/logical-time/)(logic time)
- [DHW_05](https://JF-011101.github.io/2021/mutual-exclusion-election-algorithms/)(mutual exclusion and election algorithms)
    - mutual exclusion
    - election  algorithms
- [DHW_06](https://JF-011101.github.io/2021/socket-rpc/)(socket and RPC)
    - socket communication 
    - remote procedure call(RPC)
- [DHW_07](https://JF-011101.github.io/2021/internetworking/)(internetworking)
- [DHW_08](https://JF-011101.github.io/2021/name-services/)(name services)
- [DHW_09](https://JF-011101.github.io/2021/group-communication/)(group communication)
    - Implementing Group Communication Mechanisms
    - Reliability of multicasts
    - Message ordering
    - IP multicast routing
- [DHW_10](https://JF-011101.github.io/2021/consistency-and-replication/)(Consistency and Replication)
- [DHW_11](https://JF-011101.github.io/2022/unix-fs-and-distributed-fs/)(Unix File Systems and Distributed File Systems)
- [DHW_12](https://JF-011101.github.io/2022/transaction-processing-systems/)(Transaction Processing Systems)
- [DHW_13](https://JF-011101.github.io/2022/web-searching-technologies/)(Web Searching Technologies)
- [DHW_14](https://JF-011101.github.io/2022/ds_summary/)(DistributedSystem_HongweiDu_catalogue)

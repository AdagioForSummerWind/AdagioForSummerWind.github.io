---
title: "DistributedSystem_base_03"
date: 2021-11-17T08:46:02+08:00
lastmod: 2021-12-03
tags: [distributed system]
categories: [School courses]
slug: Network and Internet Interconnection
draft: true
---
# 网络和网际互连
## 简介
## 网络类型
## 网络原理
### 数据包的传输
### 数据流
### 交换模式
### 协议
### 路由
### 拥塞控制
### 网际互连
## 互联网协议
### IP寻址
### IP协议
### IP路由
### IPv6
### 移动IP
### TCP和UDP
### 域名
### 防火墙
## 实例研究：以太网、WIFI、蓝牙
### 以太网
### IEEE 802.11无线LAN
### IEEE 802.15.1 蓝牙无线PAN
## 小结

---
title: "some_words"
date: 2021-11-25T15:48:12+08:00
lastmod: 2021-12-28
tags: [some words]
categories: [School courses]
slug: vocabulary
draft: true
---
|英文|中文|
|:--|:--|
integrate                           |整合、合并、集成
vocabulary                       |词汇
detection                          |检测、侦察、察觉
identity authentication     |身份认证
cyber threats                    |网络威胁
Transaction isolation         |事务（交易）隔离
write barrier                     |写屏障
plotter                               |阴谋家、绘图仪、描绘器
Foundations of Cryptography                  |密码（编码）学基础
Mind map                          |思维导图
|10
offline		          |离线
Classical cryptography      |古典密码学
affine		          |仿射
cipher                  |              密码
Mathematical principles    |数学原理
protocol  [ˈprəʊtəkɒl]       |协议
essence                       |      本质
universe                            |宇宙
Class Schedule Card          |课表
A civilization                |      一个文明
|20
object oriented              |   面向对象的
browser                             |浏览器
diagram                            |图表、示意图
gradient                            |坡度、斜率。倾斜的
genetic algorithm            | 遗传算法
heterogeneity                   |异质性
paradigm（s）                  |范式（g不发音）
vertical                        |      垂直的
horizontal                       |   水平的
interaction                       |  交互
|30
compensate                      | 弥补、补偿
synchronization                |  同步、同步器、同步性
symmetric                       |    对称的
dispatch                         |     派遣
negligible[ˈneɡlɪdʒəbl]        |微不足道的
vector                          |       向量
multicast                        |     多播、组播
represent                         |   代表、展现
hierarchy[ˈhaɪərɑːki]         |   等级制度、层次体系
scalability[skeɪləˈbɪlɪti]     |     可拓展性
|40
recursive                       |       递归的
iterative [ˈɪtərətɪv]            |     迭代的
intention              |                目的，打算
Serializability of Transactions      |            事务的可序列化
Durability      |                       耐久性
propagation      |                   传播
greedy                                  |贪心的
monotone [ˈmɒnətəʊn]      |  单调，单调的
render                     |              提供、给予、提交
traversal                   |             遍历，穿越，追踪
|50
sufficient                   |            足够的
accommodate                   |   容纳
underlying array               |    底层数组
vagrant                           |      流浪汉、流浪的
evacuation                         |   疏散，抽空，排气，排泄（可数）
slot                                |        狭槽、水沟；投放
garbage                           |     垃圾（~bin/can 垃圾桶）
self-discipline[ˌself ˈdɪsəplɪn] |自律
epidemic situation                | 疫情     
cursor                                    |光标      
|60
STL   (standard template library)          |标准模板库  
peer                                     |  同辈；端详
stray                                  | 迷路，误入歧途；走失的
modem[ˈməʊdem]               | 调制解调器
subscriber                    |          订阅人
DSL（digital subscriber line）|数字用户线           
hyper text                            |  超文本            
(FAQ)                     |   frequently asked question      
hierarchy                 |               层次结构
approach                   |            接近；方法
|70
general                     |              普遍的、大概的；将军 
destiny                            |       命运 

recite                 |                 背诵
dynamic                   |          动态的
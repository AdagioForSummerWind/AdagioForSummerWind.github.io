---
title: "My_fs"
date: 2021-12-16T19:44:27+08:00
lastmod: 2021-12-16
tags: [operating system]
categories: [projects]
slug: user-land-filesystem
draft: true
---
## 配置
快捷配置环境：
```

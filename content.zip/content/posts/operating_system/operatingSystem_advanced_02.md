---
title: "OperatingSystem_advanced_02"
date: 2021-12-01T11:22:00+08:00
lastmod: 2021-12-01
tags: [operating system]
categories: [Advanced learning]
slug: From code to machine running program
draft: true
---
